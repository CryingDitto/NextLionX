from django.db import models


class Post(models.Model):
    """
    Post 모델에는 제목과 내용 필드가 필요합니다.
    *이때 제목은 50글자를 초과하여 작성할 수 없도록 합니다.
    """
    pass

class Calculator:
    # 여기에 코드를 작성해보세요!